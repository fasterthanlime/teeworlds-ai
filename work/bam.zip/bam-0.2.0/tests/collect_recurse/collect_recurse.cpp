#include <iostream> 
 
using namespace std; 

extern int recurse_test();
 
int main() 
{ 
        cout << "Hello world!" << recurse_test() << endl;
        return 0; 
} 
