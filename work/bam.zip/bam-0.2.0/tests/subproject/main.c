#include <stdio.h>
#include <mod.h>

int main()
{
	printf("The string: %s", get_magic_string());
	return 0;
}
