const char *get_magic_string() { return "magic mod string!!!"; }

