/* c++ dependency checker */
int lf_dependency_cpp(struct lua_State *L);
